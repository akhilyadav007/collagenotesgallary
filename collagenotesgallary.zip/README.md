THANK YOU TO RAJASTHAN GOVERMENT FOR CONDUCTING HACKATOHN :) 
IT WAS GRAET TO BE PART OF IT ;)
********************************************************************************

# College-Notes-Gallery
## A notes management system which helps users to upload,download and manage notes of their particular course. The whole system is coded in core PHP and MySqli


### Full Video Demo
    [College Notes Gallery](https://drive.google.com/file/d/1DzeD03M4k-z8mK-Kz70smvj8iZzVYjH6/view?usp=drivesdk)

### Requirements 

- PHP 5.3 or higher recommended 
- MySQL DB
- Ability to write .htaccess file for apache mod_rewrite

### Installation
- Upload College-Notes-Gallery to the directory of your choice.
- Import MySql Db file to your database software (E.g : Php_My_Admin )
- Configure connection to your database and server by modifying connection.php file
- Navigate to the installation in your browser
- Done :)

### Login Details

1. Admin:

username: root

password: adminroot

2. User:

username: user

password: userpass

### Main Features

- Multiple user access:  Allows multiple type of users(teacher/student/admin) to login 
- Functional Admin panel:  Allows admins to manage the whole system
- CRUD functionalities:  Allows all users to create,read,update and delete their notes in a managed format 
- Profile update option:  Allows users to update their profile/account details  
- Secure registration and login option for users
- Allows students and teachers to download/upload their course notes easily
- Allows users to recover their password using forgot password option

### To-Do  list
- Add pagination for notes
- Add login with facebook and google+ option
- Add search notes option

### Issues

Please log any issues found in the repository 

### References 
freshdesignweb
Fashion Responsive Slider

### License
College Notes Gallery is created by TheAvtar team for hackathon.
